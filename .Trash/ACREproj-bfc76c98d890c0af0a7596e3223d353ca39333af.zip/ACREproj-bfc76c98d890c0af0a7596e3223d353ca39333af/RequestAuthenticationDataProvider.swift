//
//  RequestAuthenticationDataProvider.swift
//  ACRE_App
//
//  Created by MacMini1 on 10/19/15.
//  Copyright © 2015 AcreApp.Practice. All rights reserved.
//

/**import Foundation
import UIKit

class RequestAuthenticationDataProvider {

    var reqAuthToken = NSURLSessionDataTask()
    var session: NSURLSession{
        return NSURLSession.sharedSession()
    }
    
    let urlString = "http://localhost:9207/api/user/1?email=cbboyd2@gmail.com"
    
    let url = NSURL (string: urlString)
    var requestAuthentication: Bool = false
    var loggedIn: String = "Failed"
    






}**/
